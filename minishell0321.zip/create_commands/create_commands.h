
#ifndef CREATE_COMMANDS_H
# define CREATE_COMMANDS_H
char			**get_args(char *input);
#endif
