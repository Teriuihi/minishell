
#ifndef BOOL_H
# define BOOL_H
typedef enum s_bool
{
    false,
    true
}	t_bool;

#endif
